import tkinter as tk
import time
import random
import threading as td
from tkinter import messagebox

# -*- coding: UTF-8 -*-

class choujiang:

        employee_name_list = []
        employee_winers_num = 1 # the NUB of each level winer


        def __init__(self):
                self.run_f = 0

                # create windown
                self.window = tk.Tk()
                self.window.title('Lottery')
                self.window.geometry('1024x800')
                self.window.protocol('WM_DELETE_WINDOW',self.window_close)#关闭窗口提示



                self.backpng = tk.Canvas(self.window, height=800, width=1024)#创建画布
                self.photo = tk.PhotoImage(file="BACK4.gif")
                self.image = self.backpng.create_image(0,0, anchor='nw', image=self.photo)#将图片置于画布上
                self.backpng.pack(side='top')#放置画布（为上端）

    
                self.window.resizable(width=False, height=False)

                # how many winer get
                self.winer_num_lable = tk.Label(self.window,bg='Snow', fg='FireBrick',text='本轮中奖人数: ', font=('黑体', 15), width=20, height=1)
                self.winer_num_lable.place(x=650, y=435)

                self.winer_num = tk.StringVar()
                self.winer_num.set('1')
                self.entry_winer_num = tk.Entry(self.window, width=5,fg='Crimson', font=('Arial', 14), textvariable=self.winer_num,)
                self.entry_winer_num.place(x=850, y=435)

                # show final winer
                self.winer_name_lable = tk.Label(self.window, fg='FireBrick',bg='Snow',text='恭喜获奖者:', font=('黑体', 20), width=15, height=1)
                self.winer_name_lable.place(x=30, y=300)

                self.winer_show = tk.StringVar()#获奖名单展示
                self.winer_show.set('')
                self.entry_winer_show = tk.Label(self.window, font=('黑体', 20),fg='Crimson',bg='Snow', textvariable=self.winer_show, width=30,wraplength =210,height =15,justify = 'center')
                # self.entry_winer_show.pack(side='left')
                self.entry_winer_show.place(x=30, y=350)

                # rolling name
                self.rolling_name = tk.StringVar()
                self.rolling_name.set('    ')
                self.rolling_name_show = tk.Label(self.window, fg='Crimson',bg='Snow',font=('宋体', 28),textvariable=self.rolling_name, width=20,height=2)
                # self.rolling_name_show.pack(side='top')
                self.rolling_name_show.place(x=320, y=150)

                # rolling start/stop button
                self.on_hit = False
                self.hit_cnt = 0
                self.button_start_str = tk.StringVar()
                self.button_start_str.set('  Start  ')

                self.btn_start = tk.Button(self.window,bg='FireBrick',fg='Snow', font=('Kozuka Gothic Pr6N B', 24),textvariable=self.button_start_str, command=self.rolling_start)
                self.btn_start.place(x=750, y=490)

                



        def rolling_start(self):

            if self.on_hit == False:
                self.hit_cnt = self.hit_cnt + 1 # click times
                self.on_hit = True

                self.button_start_str.set('  Stop  ')
                self.winer_show.set('  ')
                self.start_thread()
            else:
                self.on_hit = False
                self.button_start_str.set('  Start  ')
                self.stop_thread()
            pass

        def stop_thread(self):
                self.run_f = 0

        def start_thread(self):
                self.run_f = 1
                self.thread_1 = td.Thread(target=self.thread_test1)
                self.thread_1.start()
               

        def thread_test1(self):

                if len(self.employee_name_list) < int(self.winer_num.get()):

                    print('请输入小于%d的人数'%(len(self.employee_name_list)))
                    self.rolling_name.set('请输入小于%d的人数'%(len(self.employee_name_list)))
                    self.button_start_str.set('Start')
                    self.on_hit = False

                else:

                    self.employee_winers_num = int(self.winer_num.get())
                    
                    while self.run_f == 1:
                        emp_list_temp = random.sample(self.employee_name_list, len(self.employee_name_list))
                        employee_winers_list = emp_list_temp[0:self.employee_winers_num]


                        i = 0
                        for emp in emp_list_temp:

                            time.sleep(0.01)
                            employee_winers_list[i % self.employee_winers_num] = emp
                            self.rolling_name.set(emp)
                            i = i + 1

                            if self.run_f != 1:
                                print("exit rolling %d %d" % (self.hit_cnt,i))
                                self.rolling_name.set("大吉大利,恭喜恭喜")
                                break

                    winer_names = ''
                    #去掉已经中奖人员
                    for name in employee_winers_list:
                        self.employee_name_list.remove(name)
                        winer_names = winer_names + name[:-1] + ' '

                    print(winer_names)
            
                    self.winer_show.set(winer_names)

        def get_all_employee_name_from_file(self, file_name):

            self.employee_name_list.clear()
            #e_names_file = open(file_name, 'r', encoding='UTF-8')
            e_names_file = open(file_name, 'r')

            for emp1 in e_names_file:
                self.employee_name_list.append(emp1)

            e_names_file.close()

        def window_close(self):
            if messagebox.askokcancel("注意", "退出将清空所有抽奖数据！！！！"):
                self.window.destroy()

lucker = choujiang()
lucker.get_all_employee_name_from_file('EMPName.csv')

lucker.window.mainloop()


